#include <stdio.h>

int b = 777;